<?php
require_once 'includes/conexao.php';
require_once 'includes/auth.php';
exigir_login();

$idu = (int)$_SESSION['id_usuario'];
$id = (int)($_GET['id'] ?? 0);

$lista = consultar($con, "SELECT * FROM vw_ranking WHERE id_produto = ? AND ativo = 1", "i", [$id]);
if (!$lista) { http_response_code(404); die('Produto não encontrado.'); }
$p = $lista[0];

$favorito = consultar($con, "SELECT 1 FROM tbl_favorito WHERE id_usuario = ? AND id_produto = ?", "ii", [$idu, $id]) ? true : false;
$historico = consultar($con, "SELECT link, origem, data_geracao FROM tbl_link_gerado WHERE id_usuario = ? AND id_produto = ? ORDER BY data_geracao DESC LIMIT 5", "ii", [$idu, $id]);

// Composição do score (mesma fórmula da view vw_ranking)
$cresc_fator = $p['vendas_anteriores'] > 0 ? ($p['vendas_30d'] - $p['vendas_anteriores']) / $p['vendas_anteriores'] : 0;
$criterios = [
    ['Volume de vendas (30 dias)', inteiro($p['vendas_30d']) . ' vendas', min($p['vendas_30d'] / 10000, 1) * 40, 40],
    ['Comissão do afiliado', number_format($p['comissao_percentual'], 1, ',', '.') . '%', min($p['comissao_percentual'] / 20, 1) * 35, 35],
    ['Crescimento de vendas', number_format($p['crescimento'], 1, ',', '.') . '%', min(max($cresc_fator, 0), 1) * 15, 15],
    ['Avaliação dos compradores', number_format($p['avaliacao'], 1, ',', '.') . ' de 5', ($p['avaliacao'] / 5) * 10, 10],
];

$titulo = $p['produto'];
$ativo = 'produtos';
include 'includes/topo.php';
?>
<p class="pequeno" style="margin-bottom:16px"><a href="produtos.php">Produtos</a> / <?= esc($p['categoria']) ?></p>

<div class="produto-topo">
  <div class="imagem"><?= esc($p['categoria']) ?></div>
  <div>
    <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px">
      <h1><?= esc($p['produto']) ?></h1>
      <span class="score <?= classe_score($p['score']) ?>" style="font-size:18px"><?= (int)$p['score'] ?></span>
    </div>
    <p class="subtitulo"><?= esc($p['descricao']) ?></p>

    <div class="dados-produto">
      <div><div class="rotulo">Preço</div><div class="valor"><?= moeda($p['preco']) ?></div></div>
      <div><div class="rotulo">Comissão</div><div class="valor"><?= number_format($p['comissao_percentual'], 1, ',', '.') ?>%</div></div>
      <div><div class="rotulo">Ganho por venda</div><div class="valor"><?= moeda($p['ganho_por_venda']) ?></div></div>
    </div>

    <div class="botoes">
      <button class="btn btn-primario" id="gerar-link" type="button" data-produto="<?= $id ?>" data-csrf="<?= csrf_token() ?>">Gerar link de afiliado</button>
      <form method="post" action="favoritar.php">
        <?= csrf_campo() ?>
        <input type="hidden" name="id_produto" value="<?= $id ?>">
        <button class="btn" type="submit"><?= $favorito ? 'Remover dos favoritos' : 'Adicionar aos favoritos' ?></button>
      </form>
      <a class="btn" href="<?= esc($p['url_shopee']) ?>" target="_blank" rel="noopener noreferrer">Ver na Shopee</a>
    </div>

    <div class="resultado-link" id="resultado-link">
      <div class="linha-copia">
        <input type="text" id="campo-link" readonly>
        <button class="btn" type="button" id="copiar-link">Copiar</button>
      </div>
      <p class="pequeno" id="msg-link" style="margin-top:6px"></p>
    </div>
  </div>
</div>

<section class="secao grade-2">
  <div>
    <div class="secao-topo"><h2>Composição da pontuação</h2></div>
    <div class="tabela-caixa"><table>
      <thead><tr><th>Critério</th><th>Valor</th><th class="num">Pontos</th></tr></thead>
      <tbody>
      <?php foreach ($criterios as $c): ?>
        <tr><td><?= esc($c[0]) ?></td><td><?= esc($c[1]) ?></td><td class="num"><?= number_format($c[2], 1, ',', '.') ?> / <?= $c[3] ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
  <div>
    <div class="secao-topo"><h2>Simulador de ganhos</h2></div>
    <div class="cartao" id="calculadora" data-ganho="<?= esc($p['ganho_por_venda']) ?>">
      <div class="campo" style="margin-bottom:0">
        <label for="calc-qtd">Vendas por mês pelo seu link</label>
        <input id="calc-qtd" type="number" min="0" value="50">
      </div>
      <div class="calc-saida" id="calc-saida"></div>
      <p class="pequeno">Estimativa mensal de comissão, considerando <?= moeda($p['ganho_por_venda']) ?> por venda.</p>
    </div>
  </div>
</section>

<?php if ($historico): ?>
<section class="secao">
  <div class="secao-topo"><h2>Seus últimos links deste produto</h2></div>
  <div class="tabela-caixa"><table>
    <thead><tr><th>Data</th><th>Tipo</th><th>Link</th></tr></thead>
    <tbody>
    <?php foreach ($historico as $h): ?>
      <tr>
        <td><?= date('d/m/Y H:i', strtotime($h['data_geracao'])) ?></td>
        <td><?= $h['origem'] === 'api' ? 'Afiliado' : 'Demonstração' ?></td>
        <td style="word-break:break-all"><?= esc($h['link']) ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</section>
<?php endif; ?>
<?php include 'includes/rodape.php'; ?>
