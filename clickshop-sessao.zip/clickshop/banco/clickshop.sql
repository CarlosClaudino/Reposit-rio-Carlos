-- ClickShop - banco de dados
-- Importe este arquivo no phpMyAdmin (aba Importar) ou rode no MySQL Workbench.

DROP DATABASE IF EXISTS clickshop;
CREATE DATABASE clickshop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE clickshop;

CREATE TABLE tbl_usuario (
    id_usuario INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    cpf VARCHAR(14) UNIQUE,
    telefone VARCHAR(20),
    senha_hash VARCHAR(255) NOT NULL,   -- password_hash() do PHP gera ~60 caracteres
    id_afiliado VARCHAR(50),            -- identificador do revendedor no programa de afiliados
    nivel ENUM('revendedor','admin') NOT NULL DEFAULT 'revendedor',
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tbl_categoria (
    id_categoria INT AUTO_INCREMENT PRIMARY KEY,
    categoria VARCHAR(60) NOT NULL UNIQUE
);

CREATE TABLE tbl_produto (
    id_produto INT AUTO_INCREMENT PRIMARY KEY,
    id_categoria INT NOT NULL,
    produto VARCHAR(150) NOT NULL,
    descricao VARCHAR(500),
    preco DECIMAL(10,2) NOT NULL,
    comissao_percentual DECIMAL(5,2) NOT NULL,   -- ex.: 12.00 = 12%
    vendas_30d INT NOT NULL DEFAULT 0,           -- vendas nos últimos 30 dias
    vendas_anteriores INT NOT NULL DEFAULT 0,    -- vendas nos 30 dias anteriores (para calcular crescimento)
    avaliacao DECIMAL(2,1) NOT NULL DEFAULT 0,   -- nota de 0 a 5
    url_shopee VARCHAR(500) NOT NULL,
    ativo TINYINT(1) NOT NULL DEFAULT 1,
    data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_categoria) REFERENCES tbl_categoria(id_categoria)
);

CREATE TABLE tbl_favorito (
    id_usuario INT NOT NULL,
    id_produto INT NOT NULL,
    data_favorito DATETIME DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id_usuario, id_produto),
    FOREIGN KEY (id_usuario) REFERENCES tbl_usuario(id_usuario) ON DELETE CASCADE,
    FOREIGN KEY (id_produto) REFERENCES tbl_produto(id_produto) ON DELETE CASCADE
);

CREATE TABLE tbl_link_gerado (
    id_link INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
    id_produto INT NOT NULL,
    link VARCHAR(500) NOT NULL,
    origem ENUM('api','demonstracao') NOT NULL,
    data_geracao DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_usuario) REFERENCES tbl_usuario(id_usuario) ON DELETE CASCADE,
    FOREIGN KEY (id_produto) REFERENCES tbl_produto(id_produto) ON DELETE CASCADE
);

-- ---------------------------------------------------------------
-- TRIGGER: guarda o e-mail sempre em minúsculas
-- ---------------------------------------------------------------
DELIMITER $$
CREATE TRIGGER trg_usuario_email_minusculo
BEFORE INSERT ON tbl_usuario
FOR EACH ROW
BEGIN
    SET NEW.email = LOWER(TRIM(NEW.email));
END $$

-- ---------------------------------------------------------------
-- PROCEDURES
-- ---------------------------------------------------------------
CREATE PROCEDURE inserir_usuario
(
IN
$nome VARCHAR(100),
$email VARCHAR(100),
$cpf VARCHAR(14),
$telefone VARCHAR(20),
$senha_hash VARCHAR(255),
$id_afiliado VARCHAR(50),
$nivel VARCHAR(10)
)
BEGIN
    INSERT INTO tbl_usuario (nome, email, cpf, telefone, senha_hash, id_afiliado, nivel)
    VALUES ($nome, $email, $cpf, $telefone, $senha_hash, $id_afiliado, $nivel);
END $$

CREATE PROCEDURE inserir_produto
(
IN
$id_categoria INT,
$produto VARCHAR(150),
$descricao VARCHAR(500),
$preco DECIMAL(10,2),
$comissao DECIMAL(5,2),
$vendas_30d INT,
$vendas_anteriores INT,
$avaliacao DECIMAL(2,1),
$url_shopee VARCHAR(500)
)
BEGIN
    INSERT INTO tbl_produto (id_categoria, produto, descricao, preco, comissao_percentual,
                             vendas_30d, vendas_anteriores, avaliacao, url_shopee)
    VALUES ($id_categoria, $produto, $descricao, $preco, $comissao,
            $vendas_30d, $vendas_anteriores, $avaliacao, $url_shopee);
END $$

CREATE PROCEDURE atualizar_produto
(
IN
$id_produto INT,
$id_categoria INT,
$produto VARCHAR(150),
$descricao VARCHAR(500),
$preco DECIMAL(10,2),
$comissao DECIMAL(5,2),
$vendas_30d INT,
$vendas_anteriores INT,
$avaliacao DECIMAL(2,1),
$url_shopee VARCHAR(500),
$ativo TINYINT
)
BEGIN
    UPDATE tbl_produto SET
        id_categoria = $id_categoria,
        produto = $produto,
        descricao = $descricao,
        preco = $preco,
        comissao_percentual = $comissao,
        vendas_30d = $vendas_30d,
        vendas_anteriores = $vendas_anteriores,
        avaliacao = $avaliacao,
        url_shopee = $url_shopee,
        ativo = $ativo
    WHERE id_produto = $id_produto;
END $$

CREATE PROCEDURE excluir_produto
(
IN
$id_produto INT
)
BEGIN
    DELETE FROM tbl_produto WHERE id_produto = $id_produto;
END $$

CREATE PROCEDURE registrar_link
(
IN
$id_usuario INT,
$id_produto INT,
$link VARCHAR(500),
$origem VARCHAR(15)
)
BEGIN
    INSERT INTO tbl_link_gerado (id_usuario, id_produto, link, origem)
    VALUES ($id_usuario, $id_produto, $link, $origem);
END $$
DELIMITER ;

-- ---------------------------------------------------------------
-- VIEW: produtos com os cálculos usados no ranking
--   ganho_por_venda = preço * comissão / 100
--   crescimento     = variação percentual de vendas entre os dois períodos
--   score (0 a 100) = 40% volume de vendas (teto 10.000 vendas)
--                   + 35% comissão (teto 20%)
--                   + 15% crescimento (teto 100%)
--                   + 10% avaliação
-- ---------------------------------------------------------------
CREATE VIEW vw_ranking AS
SELECT
    p.id_produto,
    p.produto,
    p.descricao,
    p.preco,
    p.comissao_percentual,
    p.vendas_30d,
    p.vendas_anteriores,
    p.avaliacao,
    p.url_shopee,
    p.ativo,
    c.id_categoria,
    c.categoria,
    ROUND(p.preco * p.comissao_percentual / 100, 2) AS ganho_por_venda,
    CASE WHEN p.vendas_anteriores = 0 THEN 0
         ELSE ROUND((p.vendas_30d - p.vendas_anteriores) / p.vendas_anteriores * 100, 1)
    END AS crescimento,
    ROUND(
        LEAST(p.vendas_30d / 10000, 1) * 40
      + LEAST(p.comissao_percentual / 20, 1) * 35
      + LEAST(GREATEST(
            CASE WHEN p.vendas_anteriores = 0 THEN 0
                 ELSE (p.vendas_30d - p.vendas_anteriores) / p.vendas_anteriores END, 0), 1) * 15
      + (p.avaliacao / 5) * 10
    ) AS score
FROM tbl_produto p
INNER JOIN tbl_categoria c ON c.id_categoria = p.id_categoria;

-- ---------------------------------------------------------------
-- DADOS DE EXEMPLO (valores fictícios, apenas para testar o sistema)
-- O primeiro usuário cadastrado pelo site vira administrador.
-- ---------------------------------------------------------------
INSERT INTO tbl_categoria (categoria) VALUES
('Eletrônicos'), ('Casa e Cozinha'), ('Beleza'), ('Moda'), ('Acessórios de Celular'), ('Esporte'), ('Pet');

CALL inserir_produto(1,'Fone Bluetooth TWS 5.3','Fone sem fio com estojo carregador e cancelamento de ruído',49.90,12.00,12400,8700,4.7,'https://shopee.com.br/search?keyword=fone%20bluetooth%20tws');
CALL inserir_produto(1,'Smartwatch D20','Monitor de batimentos e sono, pulseira de silicone',32.90,10.00,6100,5100,4.3,'https://shopee.com.br/search?keyword=smartwatch%20d20');
CALL inserir_produto(1,'Caixa de Som Bluetooth Portátil','Resistente a respingos, 10 horas de bateria',59.90,9.00,5200,5300,4.5,'https://shopee.com.br/search?keyword=caixa%20de%20som%20bluetooth');
CALL inserir_produto(2,'Lâmpada LED RGB Wi-Fi','Controlada por aplicativo, 16 milhões de cores',22.90,14.00,4900,4400,4.4,'https://shopee.com.br/search?keyword=lampada%20led%20rgb%20wifi');
CALL inserir_produto(2,'Garrafa Térmica Inox 1L','Mantém a temperatura por 12 horas',34.90,8.00,3800,3950,4.8,'https://shopee.com.br/search?keyword=garrafa%20termica%20inox');
CALL inserir_produto(2,'Organizador de Gaveta 6 peças','Kit de divisórias ajustáveis',18.90,15.00,7300,4100,4.6,'https://shopee.com.br/search?keyword=organizador%20de%20gaveta');
CALL inserir_produto(2,'Mini Processador Elétrico','Triturador de alho e legumes recarregável',29.90,13.00,5600,3200,4.5,'https://shopee.com.br/search?keyword=mini%20processador%20eletrico');
CALL inserir_produto(3,'Kit Maquiagem 24 peças','Sombras, batons e blush em estojo',39.90,11.00,8700,6800,4.2,'https://shopee.com.br/search?keyword=kit%20maquiagem');
CALL inserir_produto(3,'Sérum Facial Vitamina C','Frasco de 30 ml',27.90,16.00,6900,4300,4.4,'https://shopee.com.br/search?keyword=serum%20vitamina%20c');
CALL inserir_produto(4,'Camiseta Oversized Algodão','Várias cores, tamanhos P ao GG',44.90,12.00,9100,8800,4.5,'https://shopee.com.br/search?keyword=camiseta%20oversized');
CALL inserir_produto(4,'Bolsa Transversal Feminina','Material sintético, ajuste de alça',36.90,14.00,3300,2100,4.1,'https://shopee.com.br/search?keyword=bolsa%20transversal');
CALL inserir_produto(5,'Capa de Celular Transparente Reforçada','Vários modelos disponíveis',9.90,18.00,15800,15100,4.6,'https://shopee.com.br/search?keyword=capa%20celular%20transparente');
CALL inserir_produto(5,'Carregador Turbo 20W','Cabo USB-C incluso',24.90,12.00,10200,7600,4.3,'https://shopee.com.br/search?keyword=carregador%20turbo%2020w');
CALL inserir_produto(5,'Suporte Veicular Magnético','Fixação no painel',14.90,17.00,4100,2900,4.4,'https://shopee.com.br/search?keyword=suporte%20veicular%20magnetico');
CALL inserir_produto(6,'Elástico de Resistência Kit 5','Cinco níveis de carga com bolsa',26.90,15.00,4600,2800,4.6,'https://shopee.com.br/search?keyword=elastico%20de%20resistencia');
CALL inserir_produto(7,'Comedouro Automático Pet','Dispensador por gravidade',41.90,13.00,1900,900,4.2,'https://shopee.com.br/search?keyword=comedouro%20pet');

-- Consultas úteis
-- SELECT * FROM vw_ranking ORDER BY score DESC;
-- SELECT * FROM vw_ranking ORDER BY ganho_por_venda DESC;
