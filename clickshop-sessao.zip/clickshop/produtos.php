<?php
require_once 'includes/conexao.php';
require_once 'includes/auth.php';
exigir_login();

$idu = (int)$_SESSION['id_usuario'];
$q = trim($_GET['q'] ?? '');
$cat = (int)($_GET['categoria'] ?? 0);
$ordem = $_GET['ordem'] ?? 'score';

// Lista branca de ordenações (nunca colocar texto do usuário direto no ORDER BY)
$ordens = [
    'score'      => ['Pontuação', 'score DESC, vendas_30d DESC'],
    'ganho'      => ['Maior ganho por venda', 'ganho_por_venda DESC'],
    'comissao'   => ['Maior comissão', 'comissao_percentual DESC'],
    'vendas'     => ['Mais vendidos', 'vendas_30d DESC'],
    'crescimento'=> ['Maior crescimento', 'crescimento DESC'],
    'preco'      => ['Menor preço', 'preco ASC'],
];
if (!isset($ordens[$ordem])) { $ordem = 'score'; }

$sql = "SELECT r.*, (SELECT COUNT(*) FROM tbl_favorito f WHERE f.id_produto = r.id_produto AND f.id_usuario = ?) AS favorito
        FROM vw_ranking r WHERE r.ativo = 1";
$tipos = 'i';
$params = [$idu];

if ($q !== '') { $sql .= " AND r.produto LIKE ?"; $tipos .= 's'; $params[] = '%' . $q . '%'; }
if ($cat > 0)  { $sql .= " AND r.id_categoria = ?"; $tipos .= 'i'; $params[] = $cat; }
$sql .= " ORDER BY " . $ordens[$ordem][1];

$produtos = consultar($con, $sql, $tipos, $params);
$categorias = consultar($con, "SELECT id_categoria, categoria FROM tbl_categoria ORDER BY categoria");

$titulo = 'Produtos';
$ativo = 'produtos';
include 'includes/topo.php';
?>
<div class="cabecalho-pagina">
  <div>
    <h1>Produtos</h1>
    <p class="subtitulo"><?= count($produtos) ?> produto(s) encontrado(s).</p>
  </div>
</div>

<form class="filtros" method="get">
  <div class="campo">
    <label for="q">Buscar</label>
    <input id="q" name="q" type="text" value="<?= esc($q) ?>" placeholder="Nome do produto">
  </div>
  <div class="campo">
    <label for="categoria">Categoria</label>
    <select id="categoria" name="categoria">
      <option value="0">Todas</option>
      <?php foreach ($categorias as $c): ?>
        <option value="<?= (int)$c['id_categoria'] ?>" <?= $cat == $c['id_categoria'] ? 'selected' : '' ?>><?= esc($c['categoria']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="campo">
    <label for="ordem">Ordenar por</label>
    <select id="ordem" name="ordem">
      <?php foreach ($ordens as $chave => $o): ?>
        <option value="<?= $chave ?>" <?= $ordem === $chave ? 'selected' : '' ?>><?= esc($o[0]) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <button class="btn btn-primario" type="submit">Filtrar</button>
</form>

<div class="tabela-caixa">
  <table>
    <thead>
      <tr><th>Produto</th><th>Categoria</th><th class="num">Preço</th><th class="num">Comissão</th><th class="num">Ganho por venda</th><th class="num">Vendas 30d</th><th class="num">Crescimento</th><th class="num">Score</th><th></th></tr>
    </thead>
    <tbody>
    <?php foreach ($produtos as $p): ?>
      <tr>
        <td><a class="nome" href="produto.php?id=<?= (int)$p['id_produto'] ?>"><?= esc($p['produto']) ?></a></td>
        <td><?= esc($p['categoria']) ?></td>
        <td class="num"><?= moeda($p['preco']) ?></td>
        <td class="num"><?= number_format($p['comissao_percentual'], 1, ',', '.') ?>%</td>
        <td class="num"><?= moeda($p['ganho_por_venda']) ?></td>
        <td class="num"><?= inteiro($p['vendas_30d']) ?></td>
        <td class="num"><?= texto_crescimento($p['crescimento']) ?></td>
        <td class="num"><span class="score <?= classe_score($p['score']) ?>"><?= (int)$p['score'] ?></span></td>
        <td>
          <form method="post" action="favoritar.php">
            <?= csrf_campo() ?>
            <input type="hidden" name="id_produto" value="<?= (int)$p['id_produto'] ?>">
            <button class="btn btn-pequeno" type="submit"><?= $p['favorito'] ? 'Remover' : 'Favoritar' ?></button>
          </form>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$produtos): ?><tr><td colspan="9" class="vazio">Nenhum produto encontrado com esses filtros.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php include 'includes/rodape.php'; ?>
