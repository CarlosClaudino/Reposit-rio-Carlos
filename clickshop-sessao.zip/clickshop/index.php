<?php
require_once 'includes/conexao.php';
$titulo = 'Início';
$top = consultar($con, "SELECT * FROM vw_ranking WHERE ativo = 1 ORDER BY score DESC LIMIT 5");
include 'includes/topo.php';
?>
<section class="hero">
  <h1>Escolha o que divulgar com base em dados, não em palpite.</h1>
  <p>O ClickShop reúne produtos da Shopee com alto volume de vendas, comissão atrativa e crescimento recente, para que revendedores afiliados gerem seus links e divulguem os itens que mais rendem.</p>
  <?php if (logado()): ?>
    <a class="btn btn-primario" href="painel.php">Ir para o painel</a>
  <?php else: ?>
    <a class="btn btn-primario" href="cadastro.php">Criar conta gratuita</a>
    <a class="btn" href="login.php">Já tenho conta</a>
  <?php endif; ?>
</section>

<section class="secao">
  <h2>Como funciona</h2>
  <div class="passos">
    <div class="passo"><div class="n">01</div><h3>Cadastre-se</h3><p>Crie sua conta de revendedor e informe seu identificador de afiliado.</p></div>
    <div class="passo"><div class="n">02</div><h3>Analise os produtos</h3><p>Compare preço, comissão, vendas e crescimento. Cada produto recebe uma pontuação de 0 a 100.</p></div>
    <div class="passo"><div class="n">03</div><h3>Gere seu link</h3><p>Com um clique o sistema monta o link de afiliado do produto, pronto para divulgar.</p></div>
  </div>
</section>

<section class="secao">
  <div class="secao-topo"><h2>Melhor pontuação agora</h2></div>
  <div class="tabela-caixa">
    <table>
      <thead><tr><th>Produto</th><th>Categoria</th><th class="num">Comissão</th><th class="num">Ganho por venda</th><th class="num">Score</th></tr></thead>
      <tbody>
      <?php foreach ($top as $p): ?>
        <tr>
          <td><?= esc($p['produto']) ?></td>
          <td><?= esc($p['categoria']) ?></td>
          <td class="num"><?= number_format($p['comissao_percentual'], 1, ',', '.') ?>%</td>
          <td class="num"><?= moeda($p['ganho_por_venda']) ?></td>
          <td class="num"><span class="score <?= $p['score'] >= 75 ? 'alto' : ($p['score'] >= 55 ? 'medio' : 'baixo') ?>"><?= (int)$p['score'] ?></span></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$top): ?><tr><td colspan="5" class="vazio">Nenhum produto cadastrado.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php include 'includes/rodape.php'; ?>
