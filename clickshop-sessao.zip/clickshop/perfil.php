<?php
require_once 'includes/conexao.php';
require_once 'includes/auth.php';
exigir_login();

$idu = (int)$_SESSION['id_usuario'];
$erros = [];
$ok = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valido()) {
        $erros[] = 'Sessão expirada. Recarregue a página.';
    } elseif (($_POST['acao'] ?? '') === 'dados') {
        $nome = trim($_POST['nome'] ?? '');
        $telefone = trim($_POST['telefone'] ?? '');
        $afiliado = trim($_POST['id_afiliado'] ?? '');
        if (mb_strlen($nome) < 3) { $erros[] = 'Informe seu nome completo.'; }
        if (strlen(so_digitos($telefone)) < 10) { $erros[] = 'Informe um telefone com DDD.'; }
        if (!$erros) {
            executar($con, "UPDATE tbl_usuario SET nome = ?, telefone = ?, id_afiliado = ? WHERE id_usuario = ?", "sssi", [$nome, $telefone, $afiliado, $idu]);
            $_SESSION['nome'] = $nome;
            $ok = 'Dados atualizados.';
        }
    } elseif (($_POST['acao'] ?? '') === 'senha') {
        $atual = $_POST['senha_atual'] ?? '';
        $nova = $_POST['nova_senha'] ?? '';
        $conf = $_POST['confirmar'] ?? '';
        $u = consultar($con, "SELECT senha_hash FROM tbl_usuario WHERE id_usuario = ?", "i", [$idu]);
        if (!password_verify($atual, $u[0]['senha_hash'])) { $erros[] = 'A senha atual está incorreta.'; }
        if (strlen($nova) < 8) { $erros[] = 'A nova senha precisa ter pelo menos 8 caracteres.'; }
        if ($nova !== $conf) { $erros[] = 'A confirmação da nova senha não confere.'; }
        if (!$erros) {
            executar($con, "UPDATE tbl_usuario SET senha_hash = ? WHERE id_usuario = ?", "si", [password_hash($nova, PASSWORD_DEFAULT), $idu]);
            $ok = 'Senha alterada.';
        }
    }
}

$u = consultar($con, "SELECT nome, email, cpf, telefone, id_afiliado, data_cadastro FROM tbl_usuario WHERE id_usuario = ?", "i", [$idu])[0];
$links = consultar($con, "SELECT l.link, l.origem, l.data_geracao, p.produto, p.id_produto
    FROM tbl_link_gerado l INNER JOIN tbl_produto p ON p.id_produto = l.id_produto
    WHERE l.id_usuario = ? ORDER BY l.data_geracao DESC LIMIT 10", "i", [$idu]);

$titulo = 'Perfil';
$ativo = 'perfil';
include 'includes/topo.php';
?>
<div class="cabecalho-pagina">
  <div>
    <h1>Perfil</h1>
    <p class="subtitulo">Cadastro desde <?= date('d/m/Y', strtotime($u['data_cadastro'])) ?>.</p>
  </div>
</div>

<?php if ($erros): ?><div class="aviso erro"><ul><?php foreach ($erros as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>
<?php if ($ok): ?><div class="aviso ok"><?= esc($ok) ?></div><?php endif; ?>

<div class="grade-2">
  <div class="cartao">
    <h2 style="margin-bottom:16px">Dados pessoais</h2>
    <form method="post">
      <?= csrf_campo() ?>
      <input type="hidden" name="acao" value="dados">
      <div class="campo"><label for="nome">Nome</label><input id="nome" name="nome" type="text" value="<?= esc($u['nome']) ?>" required></div>
      <div class="campo"><label>E-mail</label><input type="text" value="<?= esc($u['email']) ?>" disabled></div>
      <div class="campo"><label>CPF</label><input type="text" value="<?= esc($u['cpf']) ?>" disabled></div>
      <div class="campo"><label for="telefone">Telefone</label><input id="telefone" name="telefone" type="text" data-mascara="telefone" value="<?= esc($u['telefone']) ?>" required></div>
      <div class="campo"><label for="id_afiliado">Identificador de afiliado</label><input id="id_afiliado" name="id_afiliado" type="text" value="<?= esc($u['id_afiliado']) ?>"></div>
      <button class="btn btn-primario" type="submit">Salvar dados</button>
    </form>
  </div>

  <div class="cartao">
    <h2 style="margin-bottom:16px">Alterar senha</h2>
    <form method="post" data-confere-senha>
      <?= csrf_campo() ?>
      <input type="hidden" name="acao" value="senha">
      <div class="campo"><label for="senha_atual">Senha atual</label><input id="senha_atual" name="senha_atual" type="password" required></div>
      <div class="campo"><label for="nova_senha">Nova senha</label><input id="nova_senha" name="nova_senha" type="password" minlength="8" required></div>
      <div class="campo"><label for="confirmar">Confirmar nova senha</label><input id="confirmar" name="confirmar" type="password" required><div class="dica aviso-senha"></div></div>
      <button class="btn btn-primario" type="submit">Alterar senha</button>
    </form>
  </div>
</div>

<section class="secao">
  <div class="secao-topo"><h2>Links gerados recentemente</h2></div>
  <div class="tabela-caixa">
    <table>
      <thead><tr><th>Data</th><th>Produto</th><th>Tipo</th><th>Link</th></tr></thead>
      <tbody>
      <?php foreach ($links as $l): ?>
        <tr>
          <td><?= date('d/m/Y H:i', strtotime($l['data_geracao'])) ?></td>
          <td><a class="nome" href="produto.php?id=<?= (int)$l['id_produto'] ?>"><?= esc($l['produto']) ?></a></td>
          <td><?= $l['origem'] === 'api' ? 'Afiliado' : 'Demonstração' ?></td>
          <td style="word-break:break-all"><?= esc($l['link']) ?></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$links): ?><tr><td colspan="4" class="vazio">Você ainda não gerou nenhum link.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</section>
<?php include 'includes/rodape.php'; ?>
