<?php
require_once 'includes/conexao.php';
require_once 'includes/auth.php';

if (logado()) { header('Location: painel.php'); exit; }

$erros = [];
$v = ['nome' => '', 'email' => '', 'cpf' => '', 'telefone' => '', 'id_afiliado' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valido()) { $erros[] = 'Sessão expirada. Recarregue a página e tente de novo.'; }

    foreach ($v as $campo => $_) { $v[$campo] = trim($_POST[$campo] ?? ''); }
    $senha = $_POST['senha'] ?? '';
    $confirmar = $_POST['confirmar'] ?? '';

    if (mb_strlen($v['nome']) < 3) { $erros[] = 'Informe seu nome completo.'; }
    if (!filter_var($v['email'], FILTER_VALIDATE_EMAIL)) { $erros[] = 'E-mail inválido.'; }
    if (!cpf_valido($v['cpf'])) { $erros[] = 'CPF inválido.'; }
    if (strlen(so_digitos($v['telefone'])) < 10) { $erros[] = 'Informe um telefone com DDD.'; }
    if (strlen($senha) < 8) { $erros[] = 'A senha precisa ter pelo menos 8 caracteres.'; }
    if ($senha !== $confirmar) { $erros[] = 'A confirmação de senha não confere.'; }

    if (!$erros) {
        $cpf = formatar_cpf($v['cpf']);
        $email = strtolower($v['email']);

        $existe = consultar($con, "SELECT id_usuario FROM tbl_usuario WHERE email = ? OR cpf = ?", "ss", [$email, $cpf]);
        if ($existe) {
            $erros[] = 'Já existe uma conta com esse e-mail ou CPF.';
        } else {
            // O primeiro usuário cadastrado vira administrador do sistema
            $total = consultar($con, "SELECT COUNT(*) AS total FROM tbl_usuario");
            $nivel = ($total[0]['total'] == 0) ? 'admin' : 'revendedor';
            $hash = password_hash($senha, PASSWORD_DEFAULT);

            $ok = executar($con, "CALL inserir_usuario(?, ?, ?, ?, ?, ?, ?)", "sssssss",
                [$v['nome'], $email, $cpf, $v['telefone'], $hash, $v['id_afiliado'], $nivel]);

            if ($ok) {
                $u = consultar($con, "SELECT id_usuario, nome, nivel FROM tbl_usuario WHERE email = ?", "s", [$email]);
                session_regenerate_id(true);
                $_SESSION['id_usuario'] = $u[0]['id_usuario'];
                $_SESSION['nome'] = $u[0]['nome'];
                $_SESSION['nivel'] = $u[0]['nivel'];
                header('Location: painel.php?bemvindo=1');
                exit;
            }
            $erros[] = 'Não foi possível concluir o cadastro. Tente novamente.';
        }
    }
}

$titulo = 'Criar conta';
include 'includes/topo.php';
?>
<div class="caixa-form larga">
  <h1>Criar conta</h1>
  <p class="subtitulo">Cadastro de revendedor afiliado.</p>

  <?php if ($erros): ?>
    <div class="aviso erro"><ul><?php foreach ($erros as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul></div>
  <?php endif; ?>

  <form method="post" data-confere-senha>
    <?= csrf_campo() ?>
    <div class="campo">
      <label for="nome">Nome completo</label>
      <input id="nome" name="nome" type="text" value="<?= esc($v['nome']) ?>" required>
    </div>
    <div class="campo">
      <label for="email">E-mail</label>
      <input id="email" name="email" type="email" value="<?= esc($v['email']) ?>" required>
    </div>
    <div class="linha-campos">
      <div class="campo">
        <label for="cpf">CPF</label>
        <input id="cpf" name="cpf" type="text" inputmode="numeric" placeholder="000.000.000-00" data-mascara="cpf" value="<?= esc($v['cpf']) ?>" required>
      </div>
      <div class="campo">
        <label for="telefone">Telefone</label>
        <input id="telefone" name="telefone" type="text" inputmode="numeric" placeholder="(11) 90000-0000" data-mascara="telefone" value="<?= esc($v['telefone']) ?>" required>
      </div>
    </div>
    <div class="campo">
      <label for="id_afiliado">Identificador de afiliado (opcional)</label>
      <input id="id_afiliado" name="id_afiliado" type="text" value="<?= esc($v['id_afiliado']) ?>">
      <div class="dica">Usado para identificar suas divulgações. Pode ser preenchido depois no perfil.</div>
    </div>
    <div class="linha-campos">
      <div class="campo">
        <label for="senha">Senha</label>
        <input id="senha" name="senha" type="password" minlength="8" required>
        <div class="dica">Mínimo de 8 caracteres.</div>
      </div>
      <div class="campo">
        <label for="confirmar">Confirmar senha</label>
        <input id="confirmar" name="confirmar" type="password" required>
        <div class="dica aviso-senha"></div>
      </div>
    </div>
    <button class="btn btn-primario btn-bloco" type="submit">Criar conta</button>
  </form>
  <p class="rodape-form">Já tem conta? <a href="login.php">Entrar</a></p>
</div>
<?php include 'includes/rodape.php'; ?>
