<?php
require_once 'includes/conexao.php';
require_once 'includes/auth.php';
exigir_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valido()) { header('Location: produtos.php'); exit; }

$idu = (int)$_SESSION['id_usuario'];
$idp = (int)($_POST['id_produto'] ?? 0);

$existe = consultar($con, "SELECT 1 FROM tbl_favorito WHERE id_usuario = ? AND id_produto = ?", "ii", [$idu, $idp]);
if ($existe) {
    executar($con, "DELETE FROM tbl_favorito WHERE id_usuario = ? AND id_produto = ?", "ii", [$idu, $idp]);
} else {
    executar($con, "INSERT INTO tbl_favorito (id_usuario, id_produto) SELECT ?, id_produto FROM tbl_produto WHERE id_produto = ?", "ii", [$idu, $idp]);
}

// Volta para a página de origem, se for do próprio site
$destino = 'favoritos.php';
if (!empty($_SERVER['HTTP_REFERER'])) {
    $ref = parse_url($_SERVER['HTTP_REFERER']);
    if (($ref['host'] ?? '') === $_SERVER['HTTP_HOST']) {
        $destino = $_SERVER['HTTP_REFERER'];
    }
}
header('Location: ' . $destino);
exit;
