// ClickShop - scripts da interface

// ---------- Máscaras ----------
function mascaraCPF(v) {
  v = v.replace(/\D/g, '').slice(0, 11);
  v = v.replace(/(\d{3})(\d)/, '$1.$2');
  v = v.replace(/(\d{3})(\d)/, '$1.$2');
  v = v.replace(/(\d{3})(\d{1,2})$/, '$1-$2');
  return v;
}
function mascaraTelefone(v) {
  v = v.replace(/\D/g, '').slice(0, 11);
  if (v.length > 10) return v.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
  if (v.length > 6) return v.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
  if (v.length > 2) return v.replace(/(\d{2})(\d{0,5})/, '($1) $2');
  return v;
}
document.querySelectorAll('[data-mascara="cpf"]').forEach(function (el) {
  el.addEventListener('input', function () { el.value = mascaraCPF(el.value); });
});
document.querySelectorAll('[data-mascara="telefone"]').forEach(function (el) {
  el.addEventListener('input', function () { el.value = mascaraTelefone(el.value); });
});

// ---------- Confirmação de senha ----------
var formSenha = document.querySelector('form[data-confere-senha]');
if (formSenha) {
  var s1 = formSenha.querySelector('[name="senha"], [name="nova_senha"]');
  var s2 = formSenha.querySelector('[name="confirmar"]');
  var aviso = formSenha.querySelector('.aviso-senha');
  function conferir() {
    if (!s2.value) { aviso.textContent = ''; return; }
    var igual = s1.value === s2.value;
    aviso.textContent = igual ? 'As senhas conferem.' : 'As senhas ainda não são iguais.';
    aviso.style.color = igual ? 'var(--positivo)' : 'var(--negativo)';
  }
  s1.addEventListener('input', conferir);
  s2.addEventListener('input', conferir);
  formSenha.addEventListener('submit', function (e) {
    if (s1.value !== s2.value) { e.preventDefault(); conferir(); s2.focus(); }
  });
}

// ---------- Confirmação antes de excluir ----------
document.querySelectorAll('form[data-confirma]').forEach(function (f) {
  f.addEventListener('submit', function (e) {
    if (!confirm(f.getAttribute('data-confirma'))) { e.preventDefault(); }
  });
});

// ---------- Calculadora de ganhos (página do produto) ----------
var calc = document.getElementById('calculadora');
if (calc) {
  var ganho = parseFloat(calc.getAttribute('data-ganho'));
  var campoQtd = document.getElementById('calc-qtd');
  var saida = document.getElementById('calc-saida');
  function calcular() {
    var qtd = parseInt(campoQtd.value, 10);
    if (isNaN(qtd) || qtd < 0) qtd = 0;
    var total = qtd * ganho;
    saida.textContent = total.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
  }
  campoQtd.addEventListener('input', calcular);
  calcular();
}

// ---------- Gerar e copiar link de afiliado ----------
var botaoLink = document.getElementById('gerar-link');
if (botaoLink) {
  var caixa = document.getElementById('resultado-link');
  var campoLink = document.getElementById('campo-link');
  var msg = document.getElementById('msg-link');
  var botaoCopiar = document.getElementById('copiar-link');

  botaoLink.addEventListener('click', function () {
    botaoLink.disabled = true;
    botaoLink.textContent = 'Gerando...';
    var dados = new FormData();
    dados.append('id_produto', botaoLink.getAttribute('data-produto'));
    dados.append('csrf', botaoLink.getAttribute('data-csrf'));

    fetch('gerar_link.php', { method: 'POST', body: dados })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        caixa.classList.add('visivel');
        if (j.ok) {
          campoLink.value = j.link;
          campoLink.style.display = '';
          botaoCopiar.style.display = '';
          msg.textContent = j.mensagem;
        } else {
          campoLink.style.display = 'none';
          botaoCopiar.style.display = 'none';
          msg.textContent = j.mensagem || 'Não foi possível gerar o link.';
        }
      })
      .catch(function () {
        caixa.classList.add('visivel');
        campoLink.style.display = 'none';
        botaoCopiar.style.display = 'none';
        msg.textContent = 'Falha de conexão com o servidor.';
      })
      .finally(function () {
        botaoLink.disabled = false;
        botaoLink.textContent = 'Gerar link de afiliado';
      });
  });

  botaoCopiar.addEventListener('click', function () {
    campoLink.select();
    var texto = campoLink.value;
    var pronto = function () {
      botaoCopiar.textContent = 'Copiado';
      setTimeout(function () { botaoCopiar.textContent = 'Copiar'; }, 1500);
    };
    if (navigator.clipboard) { navigator.clipboard.writeText(texto).then(pronto); }
    else { document.execCommand('copy'); pronto(); }
  });
}
