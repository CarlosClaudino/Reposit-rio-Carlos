</main>
<footer class="rodape">
  <div class="container">
    ClickShop &middot; Projeto escolar. Os dados de produtos são exemplos e não representam valores reais da Shopee.
  </div>
</footer>
<script src="<?= raiz() ?>assets/js/app.js"></script>
</body>
</html>
