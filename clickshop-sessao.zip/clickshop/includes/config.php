<?php
// Configurações gerais do ClickShop.
// Edite aqui os dados do banco e (opcionalmente) as credenciais da API de afiliados da Shopee.

define('DB_HOST', '127.0.0.1');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'clickshop');
define('DB_PORT', '3307');

// Credenciais do Shopee Affiliate Open API (painel de afiliados > Open API).
// Deixe vazio para usar o modo demonstração (o link gerado não rende comissão).
define('SHOPEE_APP_ID', '');
define('SHOPEE_SECRET', '');
define('SHOPEE_ENDPOINT', 'https://open-api.affiliate.shopee.com.br/graphql');

define('NOME_SITE', 'ClickShop');
