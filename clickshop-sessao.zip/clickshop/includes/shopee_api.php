<?php
require_once __DIR__ . '/config.php';

/**
 * Integração com o Shopee Affiliate Open API (GraphQL).
 * Autenticação: header "Authorization: SHA256 Credential=APPID, Timestamp=TS, Signature=SIG"
 * onde SIG = sha256(APPID + TS + PAYLOAD + SECRET).
 * Confira campos e limites na documentação do painel de afiliados da Shopee.
 */
function shopee_configurada() {
    return SHOPEE_APP_ID !== '' && SHOPEE_SECRET !== '';
}

function shopee_requisicao($query) {
    $payload = json_encode(['query' => $query], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $ts = time();
    $assinatura = hash('sha256', SHOPEE_APP_ID . $ts . $payload . SHOPEE_SECRET);

    $ch = curl_init(SHOPEE_ENDPOINT);
    curl_setopt_array($ch, [
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 15,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'Authorization: SHA256 Credential=' . SHOPEE_APP_ID . ', Timestamp=' . $ts . ', Signature=' . $assinatura,
        ],
    ]);
    $resposta = curl_exec($ch);
    curl_close($ch);
    if ($resposta === false) { return null; }
    return json_decode($resposta, true);
}

/**
 * Gera um link curto de afiliado para a URL de um produto.
 * Retorna o link ou null se a API falhar.
 */
function shopee_gerar_link($urlOrigem, $subId) {
    $url = addslashes($urlOrigem);
    $sub = preg_replace('/[^A-Za-z0-9_]/', '', $subId);
    $query = 'mutation { generateShortLink(input: { originUrl: "' . $url . '", subIds: ["' . $sub . '"] }) { shortLink } }';
    $dados = shopee_requisicao($query);
    return $dados['data']['generateShortLink']['shortLink'] ?? null;
}
