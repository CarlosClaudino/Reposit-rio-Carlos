<?php
// Cabeçalho comum. Antes de incluir, defina $titulo e (opcional) $ativo.
require_once __DIR__ . '/auth.php';
$r = raiz();
$ativo = $ativo ?? '';
function link_menu($arquivo, $texto, $ativo, $chave, $r) {
    $classe = ($ativo === $chave) ? ' class="ativo"' : '';
    echo '<a href="' . $r . $arquivo . '"' . $classe . '>' . $texto . '</a>';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= esc($titulo ?? 'ClickShop') ?> | ClickShop</title>
  <link rel="stylesheet" href="<?= $r ?>assets/css/style.css">
</head>
<body>
<header class="cabecalho">
  <div class="container barra">
    <a class="marca" href="<?= $r ?><?= logado() ? 'painel.php' : 'index.php' ?>">Click<span>Shop</span></a>
    <nav class="menu">
      <?php if (logado()): ?>
        <?php
          link_menu('painel.php', 'Painel', $ativo, 'painel', $r);
          link_menu('produtos.php', 'Produtos', $ativo, 'produtos', $r);
          link_menu('favoritos.php', 'Favoritos', $ativo, 'favoritos', $r);
          if (eh_admin()) { link_menu('admin/index.php', 'Gerenciar', $ativo, 'admin', $r); }
        ?>
      <?php endif; ?>
    </nav>
    <div class="conta">
      <?php if (logado()): ?>
        <a href="<?= $r ?>perfil.php" class="<?= $ativo === 'perfil' ? 'ativo' : '' ?>"><?= esc(explode(' ', $_SESSION['nome'])[0]) ?></a>
        <a href="<?= $r ?>logout.php">Sair</a>
      <?php else: ?>
        <a href="<?= $r ?>login.php">Entrar</a>
        <a href="<?= $r ?>cadastro.php" class="btn btn-primario btn-pequeno">Criar conta</a>
      <?php endif; ?>
    </div>
  </div>
</header>
<main class="container conteudo">
