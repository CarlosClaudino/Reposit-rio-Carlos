<?php
require_once __DIR__ . '/config.php';

mysqli_report(MYSQLI_REPORT_OFF);
$con = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME, DB_PORT);

if (!$con) {
    die('Não foi possível conectar ao banco de dados. Verifique includes/config.php e se o MySQL está ligado.');
}
mysqli_set_charset($con, 'utf8mb4');

/**
 * Executa uma consulta com parâmetros (prepared statement) e devolve um array de linhas.
 * Exemplo: consultar($con, "SELECT * FROM tbl_produto WHERE id_produto = ?", "i", [$id]);
 */
function consultar($con, $sql, $tipos = '', $params = []) {
    $stmt = mysqli_prepare($con, $sql);
    if (!$stmt) { return []; }
    if ($tipos !== '') { mysqli_stmt_bind_param($stmt, $tipos, ...$params); }
    mysqli_stmt_execute($stmt);
    $res = mysqli_stmt_get_result($stmt);
    $linhas = [];
    if ($res) {
        while ($l = mysqli_fetch_assoc($res)) { $linhas[] = $l; }
    }
    mysqli_stmt_close($stmt);
    return $linhas;
}

/**
 * Executa INSERT/UPDATE/DELETE/CALL com parâmetros. Retorna true se deu certo.
 */
function executar($con, $sql, $tipos = '', $params = []) {
    $stmt = mysqli_prepare($con, $sql);
    if (!$stmt) { return false; }
    if ($tipos !== '') { mysqli_stmt_bind_param($stmt, $tipos, ...$params); }
    $ok = mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    return $ok;
}
