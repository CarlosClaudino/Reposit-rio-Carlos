<?php
require_once 'includes/auth.php';

// 1) apaga os dados guardados na sessão
$_SESSION = [];

// 2) apaga o cookie da sessão no navegador
if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 3600, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}

// 3) destrói a sessão no servidor
session_destroy();

header('Location: login.php?saiu=1');
exit;
