<?php
// Endpoint chamado via JavaScript (fetch). Responde sempre em JSON.
require_once 'includes/conexao.php';
require_once 'includes/auth.php';
require_once 'includes/shopee_api.php';

header('Content-Type: application/json; charset=utf-8');

function responder($ok, $mensagem, $link = '') {
    echo json_encode(['ok' => $ok, 'mensagem' => $mensagem, 'link' => $link], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if (!logado()) { responder(false, 'Faça login para gerar links.'); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valido()) { responder(false, 'Requisição inválida. Recarregue a página.'); }

$idu = (int)$_SESSION['id_usuario'];
$idp = (int)($_POST['id_produto'] ?? 0);

$prod = consultar($con, "SELECT url_shopee FROM tbl_produto WHERE id_produto = ? AND ativo = 1", "i", [$idp]);
if (!$prod) { responder(false, 'Produto não encontrado.'); }
$url = $prod[0]['url_shopee'];

$usuario = consultar($con, "SELECT id_afiliado FROM tbl_usuario WHERE id_usuario = ?", "i", [$idu]);
$afiliado = $usuario[0]['id_afiliado'] ?: ('u' . $idu);

if (shopee_configurada()) {
    // Modo real: pede à API da Shopee um link curto de afiliado
    $link = shopee_gerar_link($url, 'clickshop_u' . $idu . '_p' . $idp);
    if (!$link) { responder(false, 'A API da Shopee não retornou o link. Confira as credenciais em includes/config.php.'); }
    $origem = 'api';
    $mensagem = 'Link de afiliado gerado pela API da Shopee.';
} else {
    // Modo demonstração: apenas marca a URL original; não gera comissão
    $link = $url . (strpos($url, '?') === false ? '?' : '&') . 'utm_source=clickshop&utm_campaign=' . urlencode($afiliado);
    $origem = 'demonstracao';
    $mensagem = 'Modo demonstração: este link não gera comissão. Configure as credenciais da API da Shopee para gerar links reais.';
}

executar($con, "CALL registrar_link(?, ?, ?, ?)", "iiss", [$idu, $idp, $link, $origem]);
responder(true, $mensagem, $link);
