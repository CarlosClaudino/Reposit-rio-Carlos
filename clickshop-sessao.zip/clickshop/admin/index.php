<?php
require_once '../includes/conexao.php';
require_once '../includes/auth.php';
exigir_admin();

$produtos = consultar($con, "SELECT * FROM vw_ranking ORDER BY id_produto DESC");
$usuarios = consultar($con, "SELECT COUNT(*) AS total FROM tbl_usuario")[0]['total'];

$titulo = 'Gerenciar produtos';
$ativo = 'admin';
include '../includes/topo.php';
?>
<div class="cabecalho-pagina">
  <div>
    <h1>Gerenciar produtos</h1>
    <p class="subtitulo"><?= count($produtos) ?> produto(s) cadastrado(s). <?= (int)$usuarios ?> usuário(s) no sistema.</p>
  </div>
  <a class="btn btn-primario" href="produto_form.php">Novo produto</a>
</div>

<?php if (isset($_GET['msg'])): ?>
  <div class="aviso ok"><?= $_GET['msg'] === 'salvo' ? 'Produto salvo.' : 'Produto excluído.' ?></div>
<?php endif; ?>

<div class="tabela-caixa">
  <table>
    <thead><tr><th>ID</th><th>Produto</th><th>Categoria</th><th class="num">Preço</th><th class="num">Comissão</th><th class="num">Score</th><th>Situação</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($produtos as $p): ?>
      <tr>
        <td class="num"><?= (int)$p['id_produto'] ?></td>
        <td><?= esc($p['produto']) ?></td>
        <td><?= esc($p['categoria']) ?></td>
        <td class="num"><?= moeda($p['preco']) ?></td>
        <td class="num"><?= number_format($p['comissao_percentual'], 1, ',', '.') ?>%</td>
        <td class="num"><?= (int)$p['score'] ?></td>
        <td><?= $p['ativo'] ? 'Ativo' : 'Oculto' ?></td>
        <td>
          <div class="acoes">
            <a class="btn btn-pequeno" href="produto_form.php?id=<?= (int)$p['id_produto'] ?>">Editar</a>
            <form method="post" action="excluir.php" data-confirma="Excluir este produto? Favoritos e links associados também serão removidos.">
              <?= csrf_campo() ?>
              <input type="hidden" name="id_produto" value="<?= (int)$p['id_produto'] ?>">
              <button class="btn btn-pequeno btn-perigo" type="submit">Excluir</button>
            </form>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$produtos): ?><tr><td colspan="8" class="vazio">Nenhum produto cadastrado.</td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php include '../includes/rodape.php'; ?>
