<?php
require_once '../includes/conexao.php';
require_once '../includes/auth.php';
exigir_admin();

$id = (int)($_GET['id'] ?? 0);
$erros = [];

$p = ['produto' => '', 'descricao' => '', 'preco' => '', 'comissao_percentual' => '', 'vendas_30d' => 0,
      'vendas_anteriores' => 0, 'avaliacao' => '4.5', 'url_shopee' => '', 'id_categoria' => 0, 'ativo' => 1];

if ($id > 0) {
    $busca = consultar($con, "SELECT * FROM tbl_produto WHERE id_produto = ?", "i", [$id]);
    if (!$busca) { die('Produto não encontrado.'); }
    $p = $busca[0];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valido()) { $erros[] = 'Sessão expirada. Recarregue a página.'; }

    $p['produto'] = trim($_POST['produto'] ?? '');
    $p['descricao'] = trim($_POST['descricao'] ?? '');
    $p['preco'] = str_replace(',', '.', trim($_POST['preco'] ?? ''));
    $p['comissao_percentual'] = str_replace(',', '.', trim($_POST['comissao_percentual'] ?? ''));
    $p['vendas_30d'] = (int)($_POST['vendas_30d'] ?? 0);
    $p['vendas_anteriores'] = (int)($_POST['vendas_anteriores'] ?? 0);
    $p['avaliacao'] = str_replace(',', '.', trim($_POST['avaliacao'] ?? '0'));
    $p['url_shopee'] = trim($_POST['url_shopee'] ?? '');
    $p['id_categoria'] = (int)($_POST['id_categoria'] ?? 0);
    $p['ativo'] = isset($_POST['ativo']) ? 1 : 0;

    if ($p['produto'] === '') { $erros[] = 'Informe o nome do produto.'; }
    if (!is_numeric($p['preco']) || $p['preco'] <= 0) { $erros[] = 'Preço inválido.'; }
    if (!is_numeric($p['comissao_percentual']) || $p['comissao_percentual'] < 0 || $p['comissao_percentual'] > 100) { $erros[] = 'Comissão deve estar entre 0 e 100.'; }
    if (!is_numeric($p['avaliacao']) || $p['avaliacao'] < 0 || $p['avaliacao'] > 5) { $erros[] = 'Avaliação deve estar entre 0 e 5.'; }
    if (!preg_match('#^https://#i', $p['url_shopee'])) { $erros[] = 'Informe o link do produto na Shopee (começando com https://).'; }
    if ($p['id_categoria'] <= 0) { $erros[] = 'Escolha uma categoria.'; }
    if ($p['vendas_30d'] < 0 || $p['vendas_anteriores'] < 0) { $erros[] = 'Vendas não podem ser negativas.'; }

    if (!$erros) {
        if ($id > 0) {
            $ok = executar($con, "CALL atualizar_produto(?,?,?,?,?,?,?,?,?,?,?)", "iissddiidsi",
                [$id, $p['id_categoria'], $p['produto'], $p['descricao'], $p['preco'], $p['comissao_percentual'],
                 $p['vendas_30d'], $p['vendas_anteriores'], $p['avaliacao'], $p['url_shopee'], $p['ativo']]);
        } else {
            $ok = executar($con, "CALL inserir_produto(?,?,?,?,?,?,?,?,?)", "issddiids",
                [$p['id_categoria'], $p['produto'], $p['descricao'], $p['preco'], $p['comissao_percentual'],
                 $p['vendas_30d'], $p['vendas_anteriores'], $p['avaliacao'], $p['url_shopee']]);
        }
        if ($ok) { header('Location: index.php?msg=salvo'); exit; }
        $erros[] = 'Não foi possível salvar o produto.';
    }
}

$categorias = consultar($con, "SELECT id_categoria, categoria FROM tbl_categoria ORDER BY categoria");

$titulo = $id > 0 ? 'Editar produto' : 'Novo produto';
$ativo = 'admin';
include '../includes/topo.php';
?>
<div class="caixa-form larga">
  <h1><?= $id > 0 ? 'Editar produto' : 'Novo produto' ?></h1>
  <p class="subtitulo">Informe os dados do produto e o link dele na Shopee.</p>

  <?php if ($erros): ?><div class="aviso erro"><ul><?php foreach ($erros as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul></div><?php endif; ?>

  <form method="post">
    <?= csrf_campo() ?>
    <div class="campo"><label for="produto">Nome do produto</label><input id="produto" name="produto" type="text" maxlength="150" value="<?= esc($p['produto']) ?>" required></div>
    <div class="campo"><label for="descricao">Descrição</label><textarea id="descricao" name="descricao" rows="3" maxlength="500"><?= esc($p['descricao']) ?></textarea></div>
    <div class="linha-campos">
      <div class="campo">
        <label for="id_categoria">Categoria</label>
        <select id="id_categoria" name="id_categoria" required>
          <option value="">Selecione</option>
          <?php foreach ($categorias as $c): ?>
            <option value="<?= (int)$c['id_categoria'] ?>" <?= $p['id_categoria'] == $c['id_categoria'] ? 'selected' : '' ?>><?= esc($c['categoria']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="campo"><label for="avaliacao">Avaliação (0 a 5)</label><input id="avaliacao" name="avaliacao" type="text" value="<?= esc($p['avaliacao']) ?>"></div>
    </div>
    <div class="linha-campos">
      <div class="campo"><label for="preco">Preço (R$)</label><input id="preco" name="preco" type="text" value="<?= esc($p['preco']) ?>" required></div>
      <div class="campo"><label for="comissao_percentual">Comissão (%)</label><input id="comissao_percentual" name="comissao_percentual" type="text" value="<?= esc($p['comissao_percentual']) ?>" required></div>
    </div>
    <div class="linha-campos">
      <div class="campo"><label for="vendas_30d">Vendas nos últimos 30 dias</label><input id="vendas_30d" name="vendas_30d" type="number" min="0" value="<?= (int)$p['vendas_30d'] ?>"></div>
      <div class="campo"><label for="vendas_anteriores">Vendas nos 30 dias anteriores</label><input id="vendas_anteriores" name="vendas_anteriores" type="number" min="0" value="<?= (int)$p['vendas_anteriores'] ?>"></div>
    </div>
    <div class="campo"><label for="url_shopee">Link do produto na Shopee</label><input id="url_shopee" name="url_shopee" type="url" value="<?= esc($p['url_shopee']) ?>" required></div>
    <?php if ($id > 0): ?>
      <div class="campo"><label><input type="checkbox" name="ativo" value="1" <?= $p['ativo'] ? 'checked' : '' ?> style="width:auto;margin-right:6px">Produto ativo (visível para os revendedores)</label></div>
    <?php endif; ?>
    <div class="botoes">
      <button class="btn btn-primario" type="submit">Salvar</button>
      <a class="btn" href="index.php">Cancelar</a>
    </div>
  </form>
</div>
<?php include '../includes/rodape.php'; ?>
