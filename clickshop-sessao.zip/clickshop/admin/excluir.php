<?php
// Versão segura do excluir.php das aulas: só aceita POST, exige admin e confere o token CSRF.
require_once '../includes/conexao.php';
require_once '../includes/auth.php';
exigir_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valido()) {
    $id = (int)($_POST['id_produto'] ?? 0);
    executar($con, "CALL excluir_produto(?)", "i", [$id]);
    header('Location: index.php?msg=excluido');
    exit;
}
header('Location: index.php');
exit;
