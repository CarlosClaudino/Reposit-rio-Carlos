<?php
require_once 'includes/conexao.php';
require_once 'includes/auth.php';
exigir_login();

$idu = (int)$_SESSION['id_usuario'];

$resumo = consultar($con, "SELECT COUNT(*) AS total,
        AVG(comissao_percentual) AS comissao_media,
        MAX(ganho_por_venda) AS maior_ganho,
        AVG(crescimento) AS crescimento_medio
    FROM vw_ranking WHERE ativo = 1")[0];

$meus_links = consultar($con, "SELECT COUNT(*) AS total FROM tbl_link_gerado WHERE id_usuario = ?", "i", [$idu])[0]['total'];
$meus_fav = consultar($con, "SELECT COUNT(*) AS total FROM tbl_favorito WHERE id_usuario = ?", "i", [$idu])[0]['total'];

$por_score = consultar($con, "SELECT * FROM vw_ranking WHERE ativo = 1 ORDER BY score DESC, vendas_30d DESC LIMIT 5");
$por_ganho = consultar($con, "SELECT * FROM vw_ranking WHERE ativo = 1 ORDER BY ganho_por_venda DESC LIMIT 5");
$por_cresc = consultar($con, "SELECT * FROM vw_ranking WHERE ativo = 1 ORDER BY crescimento DESC LIMIT 5");

$por_categoria = consultar($con, "SELECT id_categoria, categoria, COUNT(*) AS qtd, AVG(comissao_percentual) AS comissao, AVG(score) AS score
    FROM vw_ranking WHERE ativo = 1 GROUP BY id_categoria, categoria ORDER BY score DESC");

$titulo = 'Painel';
$ativo = 'painel';
include 'includes/topo.php';
?>
<div class="cabecalho-pagina">
  <div>
    <h1>Painel</h1>
    <p class="subtitulo">Olá, <?= esc(explode(' ', $_SESSION['nome'])[0]) ?>. Estes são os produtos com melhor desempenho no momento.</p>
  </div>
  <a class="btn btn-primario" href="produtos.php">Ver todos os produtos</a>
</div>

<?php if (isset($_GET['bemvindo'])): ?>
  <div class="aviso ok">Conta criada com sucesso. Complete seu identificador de afiliado no <a href="perfil.php"><u>perfil</u></a> quando quiser.</div>
<?php endif; ?>

<div class="metricas">
  <div class="cartao metrica"><div class="rotulo">Produtos ativos</div><div class="valor"><?= inteiro($resumo['total']) ?></div></div>
  <div class="cartao metrica"><div class="rotulo">Comissão média</div><div class="valor"><?= number_format((float)$resumo['comissao_media'], 1, ',', '.') ?>%</div></div>
  <div class="cartao metrica"><div class="rotulo">Maior ganho por venda</div><div class="valor"><?= moeda((float)$resumo['maior_ganho']) ?></div></div>
  <div class="cartao metrica"><div class="rotulo">Seus links / favoritos</div><div class="valor"><?= (int)$meus_links ?> / <?= (int)$meus_fav ?></div></div>
</div>

<section class="secao">
  <div class="secao-topo"><h2>Ranking por pontuação</h2><a href="produtos.php?ordem=score">ver todos</a></div>
  <div class="tabela-caixa">
    <table>
      <thead><tr><th>#</th><th>Produto</th><th>Categoria</th><th class="num">Preço</th><th class="num">Comissão</th><th class="num">Vendas 30d</th><th class="num">Crescimento</th><th class="num">Score</th></tr></thead>
      <tbody>
      <?php foreach ($por_score as $i => $p): ?>
        <tr>
          <td class="num"><?= $i + 1 ?></td>
          <td><a class="nome" href="produto.php?id=<?= (int)$p['id_produto'] ?>"><?= esc($p['produto']) ?></a></td>
          <td><?= esc($p['categoria']) ?></td>
          <td class="num"><?= moeda($p['preco']) ?></td>
          <td class="num"><?= number_format($p['comissao_percentual'], 1, ',', '.') ?>%</td>
          <td class="num"><?= inteiro($p['vendas_30d']) ?></td>
          <td class="num"><?= texto_crescimento($p['crescimento']) ?></td>
          <td class="num"><span class="score <?= classe_score($p['score']) ?>"><?= (int)$p['score'] ?></span></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>

<section class="secao grade-2">
  <div>
    <div class="secao-topo"><h2>Maior ganho por venda</h2></div>
    <div class="tabela-caixa"><table>
      <thead><tr><th>Produto</th><th class="num">Ganho</th></tr></thead>
      <tbody>
      <?php foreach ($por_ganho as $p): ?>
        <tr><td><a class="nome" href="produto.php?id=<?= (int)$p['id_produto'] ?>"><?= esc($p['produto']) ?></a></td><td class="num"><?= moeda($p['ganho_por_venda']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
  <div>
    <div class="secao-topo"><h2>Maior crescimento</h2></div>
    <div class="tabela-caixa"><table>
      <thead><tr><th>Produto</th><th class="num">Vendas</th></tr></thead>
      <tbody>
      <?php foreach ($por_cresc as $p): ?>
        <tr><td><a class="nome" href="produto.php?id=<?= (int)$p['id_produto'] ?>"><?= esc($p['produto']) ?></a></td><td class="num"><?= texto_crescimento($p['crescimento']) ?></td></tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
  </div>
</section>

<section class="secao">
  <div class="secao-topo"><h2>Desempenho por categoria</h2></div>
  <div class="tabela-caixa">
    <table>
      <thead><tr><th>Categoria</th><th class="num">Produtos</th><th class="num">Comissão média</th><th class="num">Score médio</th></tr></thead>
      <tbody>
      <?php foreach ($por_categoria as $c): ?>
        <tr>
          <td><a class="nome" href="produtos.php?categoria=<?= (int)$c['id_categoria'] ?>"><?= esc($c['categoria']) ?></a></td>
          <td class="num"><?= (int)$c['qtd'] ?></td>
          <td class="num"><?= number_format($c['comissao'], 1, ',', '.') ?>%</td>
          <td class="num"><?= number_format($c['score'], 0) ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</section>
<?php include 'includes/rodape.php'; ?>
