# ClickShop

Ferramenta web para revendedores afiliados da Shopee. O sistema reúne produtos com bom volume de vendas, comissão atrativa e crescimento recente, calcula uma pontuação para cada um e gera o link de afiliado para divulgação.

Tecnologias: HTML, CSS, JavaScript, PHP (mysqli) e MySQL.

## Como executar

### Laragon
1. Copie a pasta do projeto para `C:\laragon\www\` (de preferência com o nome `clickshop`, sem ponto no nome).
2. Inicie o Apache e o MySQL pelo Laragon (**Iniciar tudo**).
3. Importe o banco: abra o **Terminal** do Laragon, entre na pasta do projeto e rode `mysql -u root -P 3307 -h 127.0.0.1 < banco/clickshop.sql` (use a porta que aparece em *Menu > MySQL > Porta*; o padrão do Laragon é 3306). Também funciona pelo HeidiSQL (*Arquivo > Executar arquivo SQL*).
4. Confira em `includes/config.php` se `DB_PORT` é a mesma porta do seu MySQL.
5. Acesse `http://localhost/clickshop/` (ou `http://clickshop.test`).

### XAMPP
1. Copie a pasta para `C:\xampp\htdocs\` e inicie o Apache e o MySQL.
2. No phpMyAdmin, importe `banco/clickshop.sql`. Ajuste `DB_PORT` para `3306` em `includes/config.php`.
3. Acesse `http://localhost/clickshop/`.

Crie sua conta: **o primeiro usuário cadastrado vira administrador** e passa a ver o menu "Gerenciar".

## Login, logout e áreas restritas (PHP SESSION)

- `includes/auth.php` inicia a sessão (`session_start()`) e define `logado()`, `exigir_login()` e `exigir_admin()`.
- `login.php` confere e-mail e senha (`password_verify`), chama `session_regenerate_id(true)` e grava `$_SESSION['id_usuario']`, `['nome']` e `['nivel']`.
- `logout.php` limpa `$_SESSION`, apaga o cookie da sessão e chama `session_destroy()`.
- Páginas **públicas**: `index.php`, `cadastro.php`, `login.php`.
- Páginas **somente para logados** (chamam `exigir_login()` na primeira linha de PHP): `painel.php`, `produtos.php`, `produto.php`, `favoritos.php`, `favoritar.php`, `perfil.php` e o endpoint `gerar_link.php`.
- Páginas **somente para administrador** (`exigir_admin()`): tudo em `admin/`.
- Páginas restritas enviam cabeçalhos de "não guardar em cache", então o botão Voltar do navegador não mostra conteúdo restrito depois do logout.

## Estrutura

```
clickshop/
  index.php            página inicial pública
  cadastro.php         cadastro de usuário
  login.php            login
  logout.php           encerra a sessão
  painel.php           indicadores e rankings
  produtos.php         lista com busca, filtro e ordenação
  produto.php          detalhes, pontuação, simulador e geração de link
  gerar_link.php       endpoint JSON chamado pelo JavaScript
  favoritar.php        adiciona/remove favorito
  favoritos.php        lista de favoritos
  perfil.php           dados pessoais, senha e histórico de links
  admin/               CRUD de produtos (somente administrador)
  includes/            conexão, sessão/autenticação, API da Shopee, topo e rodapé
  assets/css/style.css estilos
  assets/js/app.js     máscaras, validação, calculadora, copiar link
  banco/clickshop.sql  banco completo com dados de exemplo
```

## Banco de dados

Tabelas: `tbl_usuario`, `tbl_categoria`, `tbl_produto`, `tbl_favorito`, `tbl_link_gerado`.

Recursos de SQL usados (os mesmos vistos em aula, mais alguns):

- **Procedures:** `inserir_usuario`, `inserir_produto`, `atualizar_produto`, `excluir_produto`, `registrar_link`
- **Trigger:** `trg_usuario_email_minusculo` (grava o e-mail sempre em minúsculas)
- **View:** `vw_ranking` (junta produto e categoria e calcula ganho por venda, crescimento e score)
- **Chaves estrangeiras** com `ON DELETE CASCADE` em favoritos e links
- `JOIN`, `GROUP BY`, `AVG`, `COUNT`, `MAX`, `LIKE`, `ORDER BY`

### Cálculo da pontuação (score, de 0 a 100)

| Critério | Peso | Teto considerado |
|---|---|---|
| Vendas nos últimos 30 dias | 40 | 10.000 vendas |
| Comissão do afiliado | 35 | 20% |
| Crescimento sobre os 30 dias anteriores | 15 | 100% |
| Avaliação dos compradores | 10 | nota 5 |

Ganho por venda = preço x comissão / 100.

## Integração com a API da Shopee

O arquivo `includes/shopee_api.php` usa o Shopee Affiliate Open API (GraphQL) para gerar links curtos de afiliado com a mutation `generateShortLink`. A assinatura é `SHA256(AppId + Timestamp + Payload + Secret)` enviada no header `Authorization`.

Para ativar:

1. Solicite acesso ao Open API no painel de afiliados da Shopee Brasil.
2. Preencha `SHOPEE_APP_ID` e `SHOPEE_SECRET` em `includes/config.php`.

Sem credenciais, o sistema funciona em **modo demonstração**: o link gerado é a URL do produto com parâmetros de campanha e **não gera comissão**. O histórico indica qual tipo de link foi criado.

Confira o formato exato das consultas na documentação oficial do painel de afiliados, pois a API pode mudar.

Os produtos de exemplo usam links de busca da Shopee. Em um uso real, o administrador cadastra o link de cada produto em **Gerenciar > Novo produto**.

## Diferenças em relação aos exemplos de aula

Mantivemos o estilo das aulas (`mysqli`, procedures, `while` com `fetch`), com estes cuidados adicionais:

| Aula | ClickShop | Motivo |
|---|---|---|
| `"... WHERE id = '$id'"` | `prepared statements` (`?`) | evita SQL Injection |
| `excluir.php?id=` via link (GET) | exclusão por POST com token | um link ou imagem de terceiros não consegue apagar dados |
| senha `VARCHAR(6)` em texto puro | `password_hash` / `password_verify` | senhas nunca devem ser guardadas legíveis |
| `echo $resultado['nome']` | `htmlspecialchars` (função `esc`) | evita XSS |
| sem controle de acesso | sessões, nível `admin` e token CSRF | proteger páginas e ações |

## Ideias para evoluir

- Cadastro de categorias pela área administrativa
- Importação automática de produtos pela consulta `productOfferV2` da API
- Gráfico de evolução de vendas por produto
- Relatório de conversões do afiliado (`conversionReport` da API)
