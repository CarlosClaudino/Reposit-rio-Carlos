<?php
require_once 'includes/conexao.php';
require_once 'includes/auth.php';

if (logado()) { header('Location: painel.php'); exit; }

$erro = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $senha = $_POST['senha'] ?? '';

    if (!csrf_valido()) {
        $erro = 'Sessão expirada. Recarregue a página e tente de novo.';
    } else {
        $u = consultar($con, "SELECT id_usuario, nome, senha_hash, nivel FROM tbl_usuario WHERE email = ?", "s", [$email]);
        if ($u && password_verify($senha, $u[0]['senha_hash'])) {
            session_regenerate_id(true);
            $_SESSION['id_usuario'] = $u[0]['id_usuario'];
            $_SESSION['nome'] = $u[0]['nome'];
            $_SESSION['nivel'] = $u[0]['nivel'];
            header('Location: painel.php');
            exit;
        }
        // Mensagem única, para não revelar se o e-mail existe
        $erro = 'E-mail ou senha incorretos.';
    }
}

$titulo = 'Entrar';
include 'includes/topo.php';
?>
<div class="caixa-form">
  <h1>Entrar</h1>
  <p class="subtitulo">Acesse sua conta de revendedor.</p>

  <?php if (isset($_GET['saiu'])): ?><div class="aviso ok">Você saiu da sua conta com segurança.</div><?php endif; ?>
  <?php if ($erro): ?><div class="aviso erro"><?= esc($erro) ?></div><?php endif; ?>

  <form method="post">
    <?= csrf_campo() ?>
    <div class="campo">
      <label for="email">E-mail</label>
      <input id="email" name="email" type="email" value="<?= esc($email) ?>" required autofocus>
    </div>
    <div class="campo">
      <label for="senha">Senha</label>
      <input id="senha" name="senha" type="password" required>
    </div>
    <button class="btn btn-primario btn-bloco" type="submit">Entrar</button>
  </form>
  <p class="rodape-form">Ainda não tem conta? <a href="cadastro.php">Criar conta</a></p>
</div>
<?php include 'includes/rodape.php'; ?>
