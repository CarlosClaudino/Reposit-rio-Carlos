<?php
require_once 'includes/conexao.php';
require_once 'includes/auth.php';
exigir_login();

$idu = (int)$_SESSION['id_usuario'];
$favoritos = consultar($con, "SELECT r.* FROM tbl_favorito f
    INNER JOIN vw_ranking r ON r.id_produto = f.id_produto
    WHERE f.id_usuario = ? AND r.ativo = 1 ORDER BY f.data_favorito DESC", "i", [$idu]);

$titulo = 'Favoritos';
$ativo = 'favoritos';
include 'includes/topo.php';
?>
<div class="cabecalho-pagina">
  <div>
    <h1>Favoritos</h1>
    <p class="subtitulo">Produtos que você separou para divulgar.</p>
  </div>
</div>

<div class="tabela-caixa">
  <table>
    <thead><tr><th>Produto</th><th>Categoria</th><th class="num">Preço</th><th class="num">Ganho por venda</th><th class="num">Score</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($favoritos as $p): ?>
      <tr>
        <td><a class="nome" href="produto.php?id=<?= (int)$p['id_produto'] ?>"><?= esc($p['produto']) ?></a></td>
        <td><?= esc($p['categoria']) ?></td>
        <td class="num"><?= moeda($p['preco']) ?></td>
        <td class="num"><?= moeda($p['ganho_por_venda']) ?></td>
        <td class="num"><span class="score <?= classe_score($p['score']) ?>"><?= (int)$p['score'] ?></span></td>
        <td>
          <div class="acoes">
            <a class="btn btn-pequeno" href="produto.php?id=<?= (int)$p['id_produto'] ?>">Abrir</a>
            <form method="post" action="favoritar.php">
              <?= csrf_campo() ?>
              <input type="hidden" name="id_produto" value="<?= (int)$p['id_produto'] ?>">
              <button class="btn btn-pequeno" type="submit">Remover</button>
            </form>
          </div>
        </td>
      </tr>
    <?php endforeach; ?>
    <?php if (!$favoritos): ?><tr><td colspan="6" class="vazio">Você ainda não favoritou nenhum produto. <a href="produtos.php" style="color:var(--destaque)">Ver produtos</a></td></tr><?php endif; ?>
    </tbody>
  </table>
</div>
<?php include 'includes/rodape.php'; ?>
