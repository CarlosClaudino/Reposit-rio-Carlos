# ClickShop

Ferramenta web para revendedores afiliados da Shopee. O sistema reúne produtos com bom volume de vendas, comissão atrativa e crescimento recente, calcula uma pontuação para cada um e gera o link de afiliado para divulgação.

Tecnologias: HTML, CSS, JavaScript, PHP (mysqli) e MySQL.

## Como executar

1. Instale o XAMPP (ou outro pacote com Apache, PHP 7.4+ e MySQL/MariaDB) e inicie o Apache e o MySQL.
2. Copie a pasta `clickshop` para `C:\xampp\htdocs\`.
3. Abra o phpMyAdmin (`http://localhost/phpmyadmin`), vá em **Importar** e selecione `banco/clickshop.sql`.
4. Se o seu MySQL tiver senha, ajuste `includes/config.php`.
5. Acesse `http://localhost/clickshop/`.
6. Crie sua conta. **O primeiro usuário cadastrado vira administrador** e passa a ver o menu "Gerenciar".

## Estrutura

```
clickshop/
  index.php            página inicial pública
  cadastro.php         cadastro de usuário
  login.php            login
  logout.php           encerra a sessão
  painel.php           indicadores e rankings
  produtos.php         lista com busca, filtro e ordenação
  produto.php          detalhes, pontuação, simulador e geração de link
  gerar_link.php       endpoint JSON chamado pelo JavaScript
  favoritar.php        adiciona/remove favorito
  favoritos.php        lista de favoritos
  perfil.php           dados pessoais, senha e histórico de links
  admin/               CRUD de produtos (somente administrador)
  includes/            conexão, autenticação, API da Shopee, topo e rodapé
  assets/css/style.css estilos
  assets/js/app.js     máscaras, validação, calculadora, copiar link
  banco/clickshop.sql  banco completo com dados de exemplo
```

## Banco de dados

Tabelas: `tbl_usuario`, `tbl_categoria`, `tbl_produto`, `tbl_favorito`, `tbl_link_gerado`.

Recursos de SQL usados (os mesmos vistos em aula, mais alguns):

- **Procedures:** `inserir_usuario`, `inserir_produto`, `atualizar_produto`, `excluir_produto`, `registrar_link`
- **Trigger:** `trg_usuario_email_minusculo` (grava o e-mail sempre em minúsculas)
- **View:** `vw_ranking` (junta produto e categoria e calcula ganho por venda, crescimento e score)
- **Chaves estrangeiras** com `ON DELETE CASCADE` em favoritos e links
- `JOIN`, `GROUP BY`, `AVG`, `COUNT`, `MAX`, `LIKE`, `ORDER BY`

### Cálculo da pontuação (score, de 0 a 100)

| Critério | Peso | Teto considerado |
|---|---|---|
| Vendas nos últimos 30 dias | 40 | 10.000 vendas |
| Comissão do afiliado | 35 | 20% |
| Crescimento sobre os 30 dias anteriores | 15 | 100% |
| Avaliação dos compradores | 10 | nota 5 |

Ganho por venda = preço x comissão / 100.

## Integração com a API da Shopee

O arquivo `includes/shopee_api.php` usa o Shopee Affiliate Open API (GraphQL) para gerar links curtos de afiliado com a mutation `generateShortLink`. A assinatura é `SHA256(AppId + Timestamp + Payload + Secret)` enviada no header `Authorization`.

Para ativar:

1. Solicite acesso ao Open API no painel de afiliados da Shopee Brasil.
2. Preencha `SHOPEE_APP_ID` e `SHOPEE_SECRET` em `includes/config.php`.

Sem credenciais, o sistema funciona em **modo demonstração**: o link gerado é a URL do produto com parâmetros de campanha e **não gera comissão**. O histórico indica qual tipo de link foi criado.

Confira o formato exato das consultas na documentação oficial do painel de afiliados, pois a API pode mudar.

Os produtos de exemplo usam links de busca da Shopee. Em um uso real, o administrador cadastra o link de cada produto em **Gerenciar > Novo produto**.

## Diferenças em relação aos exemplos de aula

Mantivemos o estilo das aulas (`mysqli`, procedures, `while` com `fetch`), com estes cuidados adicionais:

| Aula | ClickShop | Motivo |
|---|---|---|
| `"... WHERE id = '$id'"` | `prepared statements` (`?`) | evita SQL Injection |
| `excluir.php?id=` via link (GET) | exclusão por POST com token | um link ou imagem de terceiros não consegue apagar dados |
| senha `VARCHAR(6)` em texto puro | `password_hash` / `password_verify` | senhas nunca devem ser guardadas legíveis |
| `echo $resultado['nome']` | `htmlspecialchars` (função `esc`) | evita XSS |
| sem controle de acesso | sessões, nível `admin` e token CSRF | proteger páginas e ações |

## Ideias para evoluir

- Cadastro de categorias pela área administrativa
- Importação automática de produtos pela consulta `productOfferV2` da API
- Gráfico de evolução de vendas por produto
- Relatório de conversões do afiliado (`conversionReport` da API)
