<?php
if (session_status() === PHP_SESSION_NONE) { session_start(); }

function esc($t) { return htmlspecialchars((string)$t, ENT_QUOTES, 'UTF-8'); }
function moeda($v) { return 'R$ ' . number_format((float)$v, 2, ',', '.'); }
function inteiro($v) { return number_format((int)$v, 0, ',', '.'); }

function logado() { return isset($_SESSION['id_usuario']); }
function eh_admin() { return logado() && ($_SESSION['nivel'] ?? '') === 'admin'; }

// Caminho relativo até a raiz do site (as páginas de /admin ficam um nível abaixo)
function raiz() {
    return (strpos($_SERVER['SCRIPT_NAME'], '/admin/') !== false) ? '../' : '';
}

function exigir_login() {
    if (!logado()) { header('Location: ' . raiz() . 'login.php'); exit; }
}
function exigir_admin() {
    exigir_login();
    if (!eh_admin()) { http_response_code(403); die('Acesso restrito a administradores.'); }
}

// Proteção contra CSRF: token guardado na sessão e conferido em todo POST
function csrf_token() {
    if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
    return $_SESSION['csrf'];
}
function csrf_campo() {
    return '<input type="hidden" name="csrf" value="' . csrf_token() . '">';
}
function csrf_valido() {
    return isset($_POST['csrf'], $_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $_POST['csrf']);
}

function so_digitos($t) { return preg_replace('/\D/', '', (string)$t); }

function cpf_valido($cpf) {
    $cpf = so_digitos($cpf);
    if (strlen($cpf) != 11 || preg_match('/^(\d)\1{10}$/', $cpf)) { return false; }
    for ($t = 9; $t < 11; $t++) {
        $soma = 0;
        for ($i = 0; $i < $t; $i++) { $soma += $cpf[$i] * (($t + 1) - $i); }
        $dig = ((10 * $soma) % 11) % 10;
        if ($cpf[$t] != $dig) { return false; }
    }
    return true;
}

function formatar_cpf($cpf) {
    $d = so_digitos($cpf);
    return substr($d,0,3) . '.' . substr($d,3,3) . '.' . substr($d,6,3) . '-' . substr($d,9,2);
}

function classe_score($s) { return $s >= 75 ? 'alto' : ($s >= 55 ? 'medio' : 'baixo'); }

function texto_crescimento($c) {
    $sinal = $c > 0 ? '+' : '';
    $classe = $c > 0 ? 'sobe' : ($c < 0 ? 'desce' : '');
    return '<span class="' . $classe . '">' . $sinal . number_format($c, 1, ',', '.') . '%</span>';
}
